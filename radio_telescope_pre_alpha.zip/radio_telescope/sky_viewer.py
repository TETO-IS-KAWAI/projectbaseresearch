"""
sky_viewer.py
PySide6 3D HEALPix 천구 뷰어 — 내부 시점 (Stellarium 스타일)

원본 CelestialViewer 구조 기반.
  - 카메라 distance=40, 구 radius=50  → 카메라가 구 안쪽에 위치
  - 와인딩 정방향 유지
  - glOptions='translucent' + shader='shaded'  → 내면 렌더링 정상 작동
  - 앱 시작 시 더미 HI 온도 모델로 히트맵 즉시 표시
"""

from __future__ import annotations

import sys
from typing import Optional

import numpy as np
from astropy_healpix import HEALPix

from PySide6.QtCore import Qt, QThread, Signal, Slot
from PySide6.QtWidgets import (
    QApplication, QWidget, QMainWindow,
    QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
)
import pyqtgraph.opengl as pygl

from config import Config
from astro_processing import get_pixel_coords, _hi_temperature_model
from data_manager import get_project


# ── 색상 맵: 파랑 → 노랑 → 빨강 ────────────────────────────

def temperature_to_rgba(values: np.ndarray, vmin=None, vmax=None) -> np.ndarray:
    v      = np.asarray(values, dtype=float)
    finite = v[np.isfinite(v)]
    if len(finite) == 0:
        return np.zeros((len(v), 4), dtype=np.float32)
    if vmin is None: vmin = float(np.percentile(finite,  2))
    if vmax is None: vmax = float(np.percentile(finite, 98))
    t = np.clip((v - vmin) / max(vmax - vmin, 1e-30), 0.0, 1.0)
    r = np.where(t < 0.5, t * 2.0,           1.0)
    g = np.where(t < 0.5, t * 2.0, 2.0*(1.0 - t))
    b = np.where(t < 0.5, 1.0 - t*2.0,       0.0)
    col = np.zeros((len(v), 4), dtype=np.float32)
    col[:,0]=r; col[:,1]=g; col[:,2]=b
    col[:,3] = np.where(np.isfinite(v), 1.0, 0.0)
    return col


# ── 더미 지도 생성 스레드 ────────────────────────────────────

class DummyMapWorker(QThread):
    ready = Signal(np.ndarray)

    def __init__(self, nside: int, parent=None):
        super().__init__(parent)
        self._nside = nside

    def run(self):
        ra_all, dec_all = get_pixel_coords(self._nside)
        sky_map = np.array([
            _hi_temperature_model(float(ra), float(dec))
            for ra, dec in zip(ra_all, dec_all)
        ], dtype=np.float32)
        self.ready.emit(sky_map)


# ── GLViewWidget (원본 HealPixViewWidget 구조) ───────────────

class SkyGLView(pygl.GLViewWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.opts['fov'] = 70
        self._min_fov    = 10
        self._max_fov    = 110
        self._last       = None

    def wheelEvent(self, ev):
        delta = ev.angleDelta().y()
        new_fov = self.opts['fov'] + (2 if delta > 0 else -2)
        self.opts['fov'] = float(np.clip(new_fov, self._min_fov, self._max_fov))
        self.update()

    def mousePressEvent(self, ev):
        self._last = ev.position() if hasattr(ev, 'position') else ev.localPos()
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev):
        if self._last is None:
            super().mouseMoveEvent(ev); return
        pos  = ev.position() if hasattr(ev, 'position') else ev.localPos()
        d    = pos - self._last; self._last = pos
        if ev.buttons() == Qt.MouseButton.LeftButton:
            self.orbit(d.x(), -d.y())


# ── 메인 뷰어 위젯 ──────────────────────────────────────────

class SkyViewerWidget(QWidget):
    """
    외부 인터페이스
    ---------------
    update_from_obs(result)   obs_finished 수신 → 픽셀 갱신
    refresh_from_project()    프로젝트 열기 후 전체 갱신
    reset_map()               더미 지도로 초기화
    """

    _RADIUS = 50
    _CAM    = 40   # 카메라 거리 (< _RADIUS → 구 내부)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cfg        = Config.get()
        self._nside      = self._cfg.nside
        self._hp         = HEALPix(nside=self._nside, order='ring', frame='icrs')
        self._dummy_map: Optional[np.ndarray] = None
        self._grid_items: list = []
        self._grid_visible: bool = True
        self._build_ui()
        self._init_scene()
        self._start_dummy_worker()

    # ── UI ──────────────────────────────────────────────────

    def _build_ui(self):
        self.setStyleSheet('background:#000008;')
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        title = QLabel('HI 21cm Brightness Temperature Map')
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(
            'color:#cce8ff; font-size:14px; font-weight:600;'
            'padding:6px; background:#00000f; letter-spacing:2px;')
        root.addWidget(title)

        self._gl = SkyGLView()
        self._gl.setBackgroundColor((0, 0, 8, 255))
        root.addWidget(self._gl, stretch=1)

        bar = QWidget(); bar.setStyleSheet('background:#00000f;')
        hb  = QHBoxLayout(bar); hb.setContentsMargins(16, 5, 16, 5)
        self._status = QLabel('더미 지도 생성 중...')
        self._status.setStyleSheet('color:#7aaccc; font-size:11px;')
        hb.addWidget(self._status); hb.addStretch()

        btn_s = ('background:#0f3460; color:#cce8ff; border:none;'
                 'border-radius:3px; padding:3px 10px; font-size:11px;')
        reset = QPushButton('더미 지도로 초기화'); reset.setStyleSheet(btn_s)
        reset.clicked.connect(self.reset_map)
        hb.addWidget(reset)
        self._grid_btn = QPushButton('격자 끄기'); self._grid_btn.setStyleSheet(btn_s)
        self._grid_btn.clicked.connect(self.toggle_grid)
        hb.addWidget(self._grid_btn)
        hb.addWidget(QLabel('  드래그: 시선 이동   휠: 줌  ',
                             styleSheet='color:#334455; font-size:10px;'))
        root.addWidget(bar)

    # ── 씬 초기화 ─────────────────────────────────────────

    def _init_scene(self):
        self._gl.setCameraPosition(distance=self._CAM, elevation=0, azimuth=0)
        self._add_grid()
        self._add_labels()
        self._add_horizon()
        self._init_mesh()

    def _add_grid(self):
        """격자 추가. 아이템을 _grid_items 에 저장해 토글 가능하게."""
        self._grid_items.clear()
        line_color = (1, 1, 1, 0.25)
        r = self._RADIUS
        for lat in range(-90, 91, 15):
            phi   = np.radians(lat)
            theta = np.linspace(0, 2*np.pi, 120)
            pts   = np.column_stack([
                r*np.cos(phi)*np.cos(theta),
                r*np.cos(phi)*np.sin(theta),
                np.full(120, r*np.sin(phi)),
            ])
            item = pygl.GLLinePlotItem(pos=pts, color=line_color, width=1, antialias=True)
            self._gl.addItem(item)
            self._grid_items.append(item)
        for lon in range(0, 360, 30):
            t   = np.radians(lon)
            phi = np.linspace(-np.pi/2, np.pi/2, 120)
            pts = np.column_stack([
                r*np.cos(phi)*np.cos(t),
                r*np.cos(phi)*np.sin(t),
                r*np.sin(phi),
            ])
            item = pygl.GLLinePlotItem(pos=pts, color=line_color, width=1, antialias=True)
            self._gl.addItem(item)
            self._grid_items.append(item)


    def _add_labels(self):
        """NSEW 방위 + RA/Dec 각도 표기. _grid_items 에 포함해 토글 가능."""
        from PySide6.QtGui import QFont, QColor
        from OpenGL.GL import GL_DEPTH_TEST, GL_BLEND, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
        r = self._RADIUS * 0.96

        # depth test 비활성화 → 메쉬 위에 항상 렌더링
        _label_gl = {
            'glEnable':    [GL_BLEND],
            'glDisable':   [GL_DEPTH_TEST],
            'glBlendFunc': (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA),
        }

        def _txt(pos, text, size=14, bold=False, color=(1,1,1,0.9)):
            f = QFont('Arial', size)
            f.setBold(bold)
            item = pygl.GLTextItem(
                pos=np.array(pos, dtype=float),
                text=text,
                font=f,
                color=QColor.fromRgbF(*color),
                glOptions=_label_gl,
            )
            self._gl.addItem(item)
            self._grid_items.append(item)

        # ── 방위 (NSEW)
        _txt((0,  0,  r), 'N', size=18, bold=True, color=(1, 0.9, 0.3, 1.0))
        _txt((0,  0, -r), 'S', size=18, bold=True, color=(1, 0.9, 0.3, 1.0))
        # 내부 시점: E는 RA=90° 방향 (0,+r,0), W는 RA=270° (0,-r,0)
        _txt((0,  r,  0), 'E', size=18, bold=True, color=(1, 0.9, 0.3, 1.0))
        _txt((0, -r,  0), 'W', size=18, bold=True, color=(1, 0.9, 0.3, 1.0))

        # ── RA 각도: 적도(Dec=0)를 따라 30° 간격
        for ra_deg in range(0, 360, 30):
            t = np.radians(ra_deg)
            x = r * np.cos(t)
            y = r * np.sin(t)
            label = f'{ra_deg}°'
            _txt((x, y, r*0.05), label, size=9, color=(0.7, 0.9, 1.0, 0.8))

        # ── Dec 각도: RA=0° 자오선을 따라 15° 간격
        for dec_deg in range(-75, 91, 15):
            if dec_deg == 0:
                continue  # 적도는 RA 레이블과 겹침
            p = np.radians(dec_deg)
            x = r * np.cos(p)
            z = r * np.sin(p)
            label = f'{dec_deg:+d}°'
            _txt((x, r*0.02, z), label, size=9, color=(0.8, 1.0, 0.8, 0.8))

    def toggle_grid(self):
        """격자 표시/숨기기 토글."""
        self._grid_visible = not self._grid_visible
        for item in self._grid_items:
            item.setVisible(self._grid_visible)
        self._grid_btn.setText('격자 켜기' if not self._grid_visible else '격자 끄기')

    def _add_horizon(self):
        """원본 addHorizon 구조 그대로."""
        md = pygl.MeshData.cylinder(
            rows=1, cols=60,
            radius=[self._RADIUS, self._RADIUS], length=0.1)
        h = pygl.GLMeshItem(
            meshdata=md, smooth=True,
            color=(0.1, 0.4, 0.1, 0.2),
            shader='shaded', glOptions='translucent')
        h.rotate(90, 1, 0, 0)
        self._gl.addItem(h)

    def _init_mesh(self):
        """원본 meshInitializeHealPix 구조 그대로."""
        npix     = self._hp.npix
        lon, lat = self._hp.boundaries_lonlat(np.arange(npix), step=1)
        lon_rad  = lon.to_value('rad')
        lat_rad  = lat.to_value('rad')
        r        = self._RADIUS

        x = r * np.cos(lat_rad) * np.cos(lon_rad)
        y = r * np.cos(lat_rad) * np.sin(lon_rad)
        z = r * np.sin(lat_rad)
        verts = np.column_stack([x.flatten(), y.flatten(), z.flatten()])

        # ── 픽셀 팽창: 인접 픽셀 꼭짓점이 부동소수점 오차로 미세하게
        #    어긋나 틈이 생기는 문제를 해결.
        #    각 픽셀의 꼭짓점을 픽셀 중심에서 1.5% 바깥으로 밀어
        #    인접 픽셀끼리 살짝 겹치게 만들면 틈(검은 선)이 사라짐.
        EXPAND = 1.015
        centers_sc  = self._hp.healpix_to_skycoord(np.arange(npix))
        cx = np.cos(centers_sc.dec.rad) * np.cos(centers_sc.ra.rad)
        cy = np.cos(centers_sc.dec.rad) * np.sin(centers_sc.ra.rad)
        cz = np.sin(centers_sc.dec.rad)
        # 각 픽셀 중심을 4개 꼭짓점에 맞게 반복 (npix*4, 3)
        center_rep   = np.repeat(np.column_stack([cx, cy, cz]), 4, axis=0)
        verts_unit   = verts / r
        verts        = r * (center_rep + (verts_unit - center_rep) * EXPAND)

        # 원본과 동일한 정방향 와인딩
        faces = np.zeros((npix*2, 3), dtype=int)
        for i in range(npix):
            v0 = i * 4
            faces[i*2]     = [v0,   v0+1, v0+2]
            faces[i*2 + 1] = [v0,   v0+2, v0+3]

        dummy_colors = np.ones((npix*2, 4), dtype=np.float32) * 0.15
        dummy_colors[:, 3] = 0.9

        self._md   = pygl.MeshData(vertexes=verts, faces=faces, faceColors=dummy_colors)
        self._mesh = pygl.GLMeshItem(
            meshdata=self._md,
            smooth=False,

            glOptions='translucent',
        )
        self._gl.addItem(self._mesh)

    # ── 더미 지도 ────────────────────────────────────────────

    def _start_dummy_worker(self):
        self._worker = DummyMapWorker(nside=self._nside)
        self._worker.ready.connect(self._on_dummy_ready)
        self._worker.start()

    @Slot(np.ndarray)
    def _on_dummy_ready(self, sky_map: np.ndarray):
        self._dummy_map = sky_map
        self._apply_map(sky_map)
        finite = sky_map[np.isfinite(sky_map)]
        self._status.setText(
            f'더미 HI 모델  |  T: {finite.min():.1f} ~ {finite.max():.1f} K  '
            f'|  프로젝트를 열면 실제 관측 데이터로 갱신됩니다.')

    # ── 공개 메서드 ──────────────────────────────────────────

    @Slot(dict)
    def update_from_obs(self, result: dict):
        proj = get_project()
        if proj.sky_map is not None:
            self._apply_map(proj.sky_map)
            filled = proj.sky_map[np.isfinite(proj.sky_map)]
            self._status.setText(
                f'관측 {proj.obs_count}건  |  '
                f'T: {filled.min():.1f}~{filled.max():.1f} K  |  '
                f'RA={result["ra"]:.1f}°  Dec={result["dec"]:.1f}°  '
                f'v={result["v_radial_kms"]:+.1f} km/s'
            )

    def refresh_from_project(self):
        proj = get_project()
        if not proj.is_open or proj.sky_map is None:
            return
        if proj.nside != self._nside:
            self._gl.removeItem(self._mesh)
            self._nside = proj.nside
            self._hp    = HEALPix(nside=self._nside, order='ring', frame='icrs')
            self._init_mesh()
        self._apply_map(proj.sky_map)
        filled = proj.sky_map[np.isfinite(proj.sky_map)]
        n = len(filled)
        self._status.setText(
            f'프로젝트: {proj.name}  |  관측 {proj.obs_count}건  |  '
            f'유효 픽셀 {n}/{proj.sky_map.size}' +
            (f'  |  T: {filled.min():.1f}~{filled.max():.1f} K' if n else '')
        )

    def reset_map(self):
        if self._dummy_map is not None:
            self._apply_map(self._dummy_map)
            self._status.setText('더미 HI 모델로 초기화됨.')
        else:
            blank = np.full((self._hp.npix*2, 4), 0.15, dtype=np.float32)
            blank[:, 3] = 0.9
            self._md.setFaceColors(blank)
            self._mesh.setMeshData(meshdata=self._md)

    # ── 내부 ─────────────────────────────────────────────────

    def _apply_map(self, sky_map: np.ndarray):
        """원본 updateSky 구조 그대로, 색상 맵만 HI용으로 교체."""
        px_col   = temperature_to_rgba(sky_map)           # (npix, 4)
        face_col = np.repeat(px_col, 2, axis=0).astype(np.float32)
        # 미관측 픽셀: 어두운 회색
        unobs = face_col[:, 3] == 0
        face_col[unobs] = [0.12, 0.12, 0.12, 0.9]
        self._md.setFaceColors(face_col)
        self._mesh.setMeshData(meshdata=self._md)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = QMainWindow()
    win.setWindowTitle('Sky Viewer — 내부 시점')
    win.resize(1100, 750)
    win.setCentralWidget(SkyViewerWidget())
    win.show()
    sys.exit(app.exec())
